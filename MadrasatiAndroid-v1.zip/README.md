# Madrasati — تطبيق مدرستي

مشروع Android أصلي باستخدام Kotlin + Jetpack Compose.

## الحالة الحالية
- الواجهة الرئيسية
- الطلاب
- الفصول
- الحضور والغياب
- المواد اليومية
- الواجبات
- التقارير
- المزيد والإعدادات
- شعار المدرسة كخلفية خفيفة في الصفحات

## البناء
افتح المشروع في Android Studio ثم اختر:
Build > Build APK(s)

أو استخدم GitHub Actions الموجود في `.github/workflows/build-apk.yml` بعد رفع المشروع إلى GitHub.
