package tz.alkhaleej.madrasati

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0D4773)
private val Teal = Color(0xFF168A8A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MadrasatiApp() }
    }
}

@Composable
fun MadrasatiApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Teal,
            background = Color(0xFFF7F9FC)
        )
    ) {
        var selected by remember { mutableStateOf(0) }
        val titles = listOf("الرئيسية", "الطلاب", "الفصول", "الحضور والغياب", "المزيد")

        Scaffold(
            bottomBar = {
                NavigationBar {
                    val items = listOf(
                        Icons.Default.Home to "الرئيسية",
                        Icons.Default.People to "الطلاب",
                        Icons.Default.School to "الفصول",
                        Icons.Default.EventAvailable to "الحضور",
                        Icons.Default.Menu to "المزيد"
                    )
                    items.forEachIndexed { index, pair ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(pair.first, null) },
                            label = { Text(pair.second, fontSize = 11.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                Modifier.fillMaxSize().padding(padding).background(Color(0xFFF7F9FC))
            ) {
                Image(
                    painter = painterResource(R.drawable.school_logo),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize().alpha(0.045f),
                    contentScale = ContentScale.Inside
                )
                when (selected) {
                    0 -> HomeScreen()
                    1 -> StudentsScreen()
                    2 -> ClassesScreen()
                    3 -> AttendanceScreen()
                    else -> MoreScreen()
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp)) {
        Text(title, color = Navy, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Color.Gray, fontSize = 13.sp)
    }
}

@Composable
fun HomeScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("مدرسة الخليج الإسلامية", color = Navy, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("العلم قبل القول والعمل", color = Teal, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
        }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, null, tint = Navy, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("مرحباً بك في تطبيق مدرستي", fontWeight = FontWeight.Bold, color = Navy)
                        Text("معاً من أجل تعليم أفضل ومستقبل مشرق", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
        item { MenuGrid() }
    }
}

@Composable
fun MenuGrid() {
    val menus = listOf(
        Triple(Icons.Default.People, "الطلاب", "إدارة بيانات الطلاب"),
        Triple(Icons.Default.School, "الفصول", "عرض وإدارة الفصول"),
        Triple(Icons.Default.EventAvailable, "الحضور والغياب", "تسجيل حضور الطلاب"),
        Triple(Icons.Default.MenuBook, "المواد اليومية", "المواد التي دُرست"),
        Triple(Icons.Default.EditNote, "الواجبات المنزلية", "متابعة الواجبات"),
        Triple(Icons.Default.BarChart, "التقارير", "تقارير الطلاب والفصول")
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        menus.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (icon, title, desc) ->
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(Color.White)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Icon(icon, null, tint = Navy, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.height(7.dp))
                            Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(desc, color = Color.Gray, fontSize = 10.sp)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun StudentsScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("الطلاب", "إدارة ومتابعة بيانات الطلاب")
        val students = listOf("أحمد محمد علي", "حسن علي جمعة", "عمر سعيد سالم", "إبراهيم حميسي", "يوسف عبد الله")
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(students.size) { i ->
                StudentRow(students[i], if (i == 1) "غائب" else if (i == 2) "مريض" else "حاضر")
            }
        }
    }
}

@Composable
fun StudentRow(name: String, status: String) {
    val color = when(status) { "حاضر" -> Color(0xFF2E9D50); "غائب" -> Color(0xFFD63D3D); else -> Color(0xFFD39A00) }
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(Color.White)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountCircle, null, tint = Navy, modifier = Modifier.size(42.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold)
                Text("الصف الأول", color = Color.Gray, fontSize = 12.sp)
            }
            Surface(color = color.copy(alpha = .12f), shape = RoundedCornerShape(50)) {
                Text(status, color = color, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ClassesScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("الفصول", "عرض وإدارة الفصول الدراسية")
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(6) { i ->
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.School, null, tint = Teal, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("الصف ${i + 1}A", fontWeight = FontWeight.Bold, color = Navy)
                            Text("${12 - (i / 2)} طلاب  •  المعلم: الأستاذ حسن", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AttendanceScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("الحضور والغياب", "اليوم • الصف الأول")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("حاضر", "10", Color(0xFF2E9D50))
            Stat("غائب", "2", Color(0xFFD63D3D))
            Stat("مريض", "1", Color(0xFFD39A00))
            Stat("المجموع", "13", Navy)
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(8) { i ->
                StudentRow(listOf("أحمد محمد علي","حسن علي جمعة","عمر سعيد سالم","إبراهيم حميسي","يوسف عبد الله","سليمان راشد","بلال حسن","عبد الله سعيد")[i],
                    when(i) { 1,6 -> "غائب"; 2 -> "مريض"; else -> "حاضر" })
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String, color: Color) {
    Card(Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(color.copy(alpha = .10f))) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(label, color = color, fontSize = 11.sp)
        }
    }
}

@Composable
fun MoreScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("المزيد", "إعدادات وخدمات التطبيق")
        val items = listOf(
            Icons.Default.Settings to "الإعدادات",
            Icons.Default.Notifications to "الإشعارات",
            Icons.Default.Help to "المساعدة والدعم",
            Icons.Default.Info to "حول التطبيق"
        )
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items.size) { i ->
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(items[i].first, null, tint = Navy, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(14.dp))
                        Text(items[i].second, fontWeight = FontWeight.Bold, color = Navy)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                    }
                }
            }
        }
    }
}
